clc;
clear all
close all
%% My model
Ap=[0.967838 0 0.223873 0;0 0.973789 0 0.198115;0 0 0.772288 0;0 0 0 0.799143];
Bp=[0.0218961 0.000310386;0.000172689 0.0234726;0 0.00232901;0.00149836 0];
Cp=[1 0 0 0;0 1 0 0];
% Np=input('Np=');
% Nc=input('Nc=');
Np=100;
Nc=20;
rw=[80 1]';
[~,ni]=size(Bp);
[q,n1]=size(Cp);
n=n1+q;
A_e=zeros(n,n);
B_e=zeros(n,ni);
C_e=zeros(q,n);
A_e(1:n1,1:n1)=Ap;
A_e(n1+1:n,1:n1)=Cp*Ap;
A_e(1+n1:n,n1+1:n)=eye(q,q);
B_e(1:n1,1:ni)=Bp;
B_e(n1+1:n,1:ni)=Cp*Bp;
C_e(:,n1+1:n)=eye(q,q);
y=zeros(q,1);
u=zeros(ni,1);
x_ki=[0 0 0 0 0 0]';
xm_ki=[0 0 0 0]';
ym_ki=[0 0]';
u_ki=[0 0]';
Nsim=500;
for k=1:Nc
   weighting_R1(((k-1)*ni)+1:k*ni,:)=rw ;
end
    weighting_R=diag(weighting_R1);
    setpoint_choose=input('setpoint=');
    %% Creating Phi and F matrices
    F=zeros(q*Np,n);
    Phi=zeros(q*Np,Nc*ni);
    u(1:q,1:n)=C_e;
    F(1:q,1:n)=C_e*A_e;
    for i=2:Np
       F(((i-1)*q)+1:i*q,1:n)=F(((i-2)*q)+1:(i-1)*q,1:n)*A_e;
         u(((i-1)*q)+1:i*q,1:n)=u(((i-2)*q)+1:(i-1)*q,1:n)*A_e;
    end
                    U1=u*B_e;
                    Phi(1:q*Np,1:ni)=U1;
                    for kk=2:Nc
                       Phi(1:q*Np,((kk-1)*ni)+1:kk*ni)=[zeros(kk-1,ni);U1(1:(q*Np)-kk+1,:)]; 
                        
                    end
                    %% Creating Phi_Phi ,...
                    Rbar=zeros(q*Np,1);
                    for qq=1:Np
                       Rbar((qq-1)*q+1:(qq*q),:)=setpoint_choose; 
                    end
                                    
                   Phi_Phi=Phi'*Phi;
                   Phi_R=Phi'*Rbar;
                   Phi_F=Phi'*F;
                   Kmpc=(Phi_Phi+weighting_R)\Phi_F;
                   Ky=(Phi_Phi+weighting_R)\Phi_R;
                  % setpoint1=[ones(Nsim/4,1);zeros(Nsim/4,1);ones(Nsim/4,1);zeros(Nsim/4,1)];
                  setpoint1=ones(Nsim,1);
                   %% Delta_u
                   Delta_u=(Ky)-(Kmpc*x_ki);
                   %% Creating Receding Horizon 
                   a1=zeros(ni,Nc*ni);
                   a1(:,1:ni)=eye(ni,ni);
                   Delta_u_Horizon=a1*Delta_u;
                   for pp=1:Nsim
                       
                       xm_old=xm_ki;
                       u_ki=u_ki+Delta_u_Horizon;
                       u1(((pp-1)*ni)+1:pp*ni,:)=u_ki;
                       y1(((pp-1)*q)+1:pp*q,:)=ym_ki;
                       xm_ki=Ap*xm_ki+Bp*u_ki;
                       ym_ki=Cp*xm_ki;
                       Xf=[xm_ki-xm_old;ym_ki];
                      Delta_u=(Ky)-(Kmpc*Xf);
                       Delta_u_Horizon=a1*Delta_u; 
                   end
                   %% plot
                   y_1=zeros(Nsim,1);
                   y_2=zeros(Nsim,1);
                   u_1=zeros(Nsim,1);
                   u_2=zeros(Nsim,1);
                   for o=1:Nsim
                      y_1(o)=y1(2*o-1);
                      y_2(o)=y1(2*o);
                      u_1(o)=u1(2*o-1);
                      u_2(o)=u1(2*o);
                   end
                   k1=(0:Nsim-1);
                   figure(1)
                   grid on
                   subplot(211)
                   plot(k1,y_1,'r')
                   hold on
                   plot(k1,y_2,'b')
                   hold on 
                   plot(k1,setpoint1,'color',[0 1 0])
                   xlabel('Sample')
                   legend('Output1','Output2')
                   grid minor
                   subplot(212)
                    plot(k1,u_1,'r')
                   hold on
                   plot(k1,u_2,'b')
                   xlabel('Sample')
                   legend('input1','input2')
                   grid minor
    