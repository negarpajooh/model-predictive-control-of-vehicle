clear
clc
close all
format long
global Ap Bp Cp Dp
%%
lr=1;lf=.5;m=1818.2;g=10;a0=1.5;a1=0;a2=1050;a3=1200;a4=7;
a5=0;a6=0.2;alfa_r=pi/4;alfa_f=pi/4;betta=pi/2;
vx=3;G0=9.2e-3;
Iz=3885;
%%
params.lr=lr;params.lf=lf;params.m=m;params.g=g;params.a0=a0;
params.a1=a1;params.a2=a2;params.a3=a3;params.a4=a4;
params.a5=a5;params.a6=a6;params.alfa_r=alfa_r;
params.alfa_f=alfa_f;params.Iz=Iz;params.betta=betta;
params.vx=vx;params.G0=G0;
%%
[Fzf,Fzr]=Fz(params);
[Cf,Df,Bf,Ef]=CDBE(params,Fzf);
[Cr,Dr,Br,Er]=CDBE(params,Fzr);
%%
Cf=Fy1(alfa_f,Bf,Cf,Df,Ef);
Cr=Fy1(alfa_r,Br,Cr,Dr,Er);
%% A B C D
[Ap,Bp,Cp,Dp]=StateSpace(params,Cf,Cr);
% Ap=[-3.785 -19.167 0 0
%     0.469 0.976 0 0
%     0 1 0 0
%     1 0 20 0];
% Bp=[34.409;27.686;0;0];
% Cp=eye(4);
% Dp=zeros(4,1);
%
Ap=[-3.785 -19.167
    0.469 0.976];
Bp=[34.409;27.686];
Cp=ones(2);
Dp=zeros(2,1);
%
sys=ss(Ap,Bp,Cp,Dp);
mpctool
%% ctrb  obsv
zCtrl=ctrb(Ap,Bp);
zObsv=obsv(Ap,Cp);
%
RankAp=rank(Ap);
RankCtrl=rank(zCtrl);
RankObsv=rank(zObsv);
%
%%
t=0:0.001:1;
u=.1.*eye(numel(t),1);
% u1=sin(0.5.*t*pi);
% u=u1'.*ones(numel(t),1);
[y,~,~]=lsim(sys,u,t);
% plot(y(:,1))
% hold on
% plot(y(:,2))
% hold on
% plot(y(:,3))
% hold on
% plot(y(:,4))
% sim('AutoCar')
%% Farasars
% Np=input('Np=');
% Nc=input('Nc=');
% setpoint_choose=input('setpoint=');
% Np=20;
% Nc=10;
% setpoint_choose=20;
% rw=[10 10]';
% [~,ni]=size(Bp);
% [q,n1]=size(Cp);
% n=n1;
% A_e=Ap;
% B_e=Bp;
% C_e=Cp;
% y=zeros(q,1);
% u=zeros(ni,1);
% x_ki=[0 0]';
% xm_ki=[0 0]';
% ym_ki=[0 0]';
% u_ki=[0 0]';
% Nsim=500;
% for k=1:Nc
%    weighting_R1(((k-1)*ni)+1:k*ni,:)=rw ;
% end
% weighting_R=diag(weighting_R1);
% %     weighting_R=(weighting_R1);
%     %% Creating Phi and F matrices
%     F=zeros(q*Np,n);
%     Phi=zeros(q*Np,Nc*ni);
%     u(1:q,1:n)=C_e;
%     F(1:q,1:n)=C_e*A_e;
%     for i=2:Np
%        F(((i-1)*q)+1:i*q,1:n)=F(((i-2)*q)+1:(i-1)*q,1:n)*A_e;
%          u(((i-1)*q)+1:i*q,1:n)=u(((i-2)*q)+1:(i-1)*q,1:n)*A_e;
%     end
%                     U1=u*B_e;
%                     Phi(1:q*Np,1:ni)=U1;
%                     for kk=2:Nc
%                        Phi(1:q*Np,((kk-1)*ni)+1:kk*ni)=[zeros(kk-1,ni);U1(1:(q*Np)-kk+1,:)]; 
%                         
%                     end
%                     %% Creating Phi_Phi ,...
%                     Rbar=zeros(q*Np,1);
%                     for qq=1:Np
%                        Rbar((qq-1)*q+1:(qq*q),:)=setpoint_choose; 
%                     end
%                                     
%                    Phi_Phi=Phi'*Phi;
%                    Phi_R=Phi'*Rbar;
%                    Phi_F=Phi'*F;
%                    Kmpc=(Phi_Phi+weighting_R)\Phi_F;
%                    Ky=(Phi_Phi+weighting_R)\Phi_R;
%                   % setpoint1=[ones(Nsim/4,1);zeros(Nsim/4,1);ones(Nsim/4,1);zeros(Nsim/4,1)];
%                   setpoint1=ones(Nsim,1);
% %% Delta_u
%                    Delta_u=(Ky)-(Kmpc*xm_ki);
%                    %% Creating Receding Horizon 
%                    a1=zeros(ni,Nc*ni);
%                    a1(:,1:ni)=eye(ni,ni);
%                    Delta_u_Horizon=a1*Delta_u;
%                    for pp=1:Nsim
%                        
%                        xm_old=xm_ki;
%                        u_ki=u_ki+Delta_u_Horizon;
%                        u1(((pp-1)*ni)+1:pp*ni,:)=u_ki;
%                        y1(((pp-1)*q)+1:pp*q,:)=ym_ki;
%                        xm_ki=A_e*xm_ki+Bp*u_ki;
%                        ym_ki=C_e*xm_ki;
%                       Delta_u=(Ky)-(Kmpc*xm_ki);
%                        Delta_u_Horizon=a1*Delta_u;  
%                    end
%                    %% plot
%                    y_1=zeros(Nsim,1);
%                    y_2=zeros(Nsim,1);
%                    u_1=zeros(Nsim,1);
%                    u_2=zeros(Nsim,1);
%                    for o=1:Nsim
%                       y_1(o)=y1(2*o-1);
%                       y_2(o)=y1(2*o);
%                       u_1(o)=u1(2*o-1);
%                       u_2(o)=u1(2*o); 
%                    end
%                    k1=(0:Nsim-1);
%                    figure(1)
%                    grid on
%                    subplot(211)
%                    plot(k1,y_1,'r') 
%                    hold on
%                    plot(k1,y_2,'b')
%                    hold on 
%                    plot(k1,setpoint1,'color',[0 1 0])
%                    xlabel('Sample')
%                    legend('Output1','Output2')
%                    grid minor
%                    subplot(212)
%                    plot(k1,u_1,'r')
%                    hold on
%                    plot(k1,u_2,'b')
%                    xlabel('Sample')
%                    legend('input1','input2')
%                    grid minor
%     